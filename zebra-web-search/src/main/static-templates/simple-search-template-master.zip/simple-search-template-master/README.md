# simple-search-template
A simple bootstrap template for simple search pages.
